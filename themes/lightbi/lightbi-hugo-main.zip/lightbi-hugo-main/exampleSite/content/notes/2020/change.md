---
title: Note 1
date: 2020-02-01 
---
Journaling is not just a little thing you do to pass the time, to write down your memories—though it can be—it’s a strategy that has helped brilliant, powerful and wise people become better at what they do. 
 