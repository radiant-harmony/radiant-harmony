---
title: Build a Hugo Blog
date: 2021-01-31
tags: ["hugo","blog"]
image : "/img/posts/img-2.jpg"
Description  : "It’s a fast and static website generator written in the Go language. Websites built with Hugo can be hosted anywhere from GitHub..."
featured: true
---

### Hugo?

It’s a fast and static website generator written in the Go language. Websites built with Hugo can be hosted anywhere from GitHub Pages to Amazon S3 without any database or other language dependencies.

First I started to use Hugo is for my Malayalam write up a blog wizbi tales (Malayalam is a language spoken in Kerala, India), After the initial learning curves, I loved it for simplicity and performance. And when I started this blog itself I didn’t think twice.

Okay, Now let’s start. the below section shows how to install Hugo in Windows and develop a blog in it.

If you want to know hwo to instal hugo and make a blog in it [click here](https://binovarghese.com/blog/build-your-first-hugo-blog/).

<!--Photo by Robert Katzki on Unsplash-->
